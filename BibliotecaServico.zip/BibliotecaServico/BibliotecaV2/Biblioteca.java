package ProjetoBiblioteca;

import java.util.ArrayList;
import java.util.HashMap;

public class Biblioteca {
    private ArrayList<livro> livros; // Lista de livros no acervo
    private HashMap<Integer, Usuario> usuarios; // Mapeia matrícula para o usuário

    public Biblioteca() {
        this.livros = new ArrayList<>();
        this.usuarios = new HashMap<>();
    }

    // Método para adicionar um livro ao acervo
    public void adicionarLivro(livro novoLivro) {
        livros.add(novoLivro);
        System.out.println("Livro adicionado ao acervo: " + novoLivro.getTitulo());
    }

    // Método para cadastrar um novo usuário
    public void cadastrarUsuario(Usuario novoUsuario) {
        if (usuarios.containsKey(novoUsuario.getMatricula())) {
            System.out.println("Usuário com matrícula " + novoUsuario.getMatricula() + " já está cadastrado.");
        } else {
            usuarios.put(novoUsuario.getMatricula(), novoUsuario);
            System.out.println("Usuário cadastrado com sucesso: " + novoUsuario.getNome());
        }
    }

    // Método para realizar empréstimo de um livro
    public void emprestarLivro(int matriculaUsuario, String tituloLivro) {
        Usuario usuario = usuarios.get(matriculaUsuario);
        if (usuario == null) {
            System.out.println("Usuário não encontrado.");
            return;
        }

        for (livro l : livros) {
            if (l.getTitulo().equalsIgnoreCase(tituloLivro)) {
                l.emprestar();
                return;
            }
        }
        System.out.println("Livro não encontrado no acervo.");
    }

    // Método para devolver um livro
    public void devolverLivro(String tituloLivro) {
        for (livro l : livros) {
            if (l.getTitulo().equalsIgnoreCase(tituloLivro)) {
                l.devolver();
                return;
            }
        }
        System.out.println("Livro não encontrado no acervo.");
    }

    // Método para exibir todos os livros
    public void listarLivros() {
        System.out.println("Lista de Livros no Acervo:");
        for (livro l : livros) {
            System.out.println("- " + l.getTitulo() + " (Disponíveis: " + l.getNumExemplaresDisponiveis() + ")");
        }
    }

    // Método para listar todos os usuários cadastrados
    public void listarUsuarios() {
        System.out.println("Lista de Usuários Cadastrados:");
        for (Usuario u : usuarios.values()) {
            System.out.println("- " + u.getNome() + " (Matrícula: " + u.getMatricula() + ")");
        }
    }
}
