package ProjetoBiblioteca;

public class Principal {
    public static void main(String[] args) {
        Cadastro cadastro = new Cadastro();

        System.out.println("=== Sistema de Biblioteca ===");
        System.out.println("1. Cadastrar Aluno");
        System.out.println("2. Cadastrar Professor");
        System.out.println("3. Cadastrar Funcionário");
        System.out.println("4. Cadastrar Livro");
        System.out.println("5. Sair");

        boolean rodando = true;

        while (rodando) {
            System.out.print("\nEscolha uma opção: ");
            int opcao = cadastro.scanner.nextInt();
            cadastro.scanner.nextLine(); // Consumir quebra de linha

            switch (opcao) {
                case 1:
                    // Cadastrar Aluno
                    Usuario aluno = cadastro.cadastroAluno();
                    if (aluno != null) {
                        System.out.println("Aluno cadastrado com sucesso: " + aluno.getNome());
                    }
                    break;
                case 2:
                    // Cadastrar Professor
                    Usuario professor = cadastro.cadastroProfessor();
                    if (professor != null) {
                        System.out.println("Professor cadastrado com sucesso: " + professor.getNome());
                    }
                    break;
                case 3:
                    // Cadastrar Funcionário
                    Usuario funcionario = cadastro.cadastroFuncionario();
                    if (funcionario != null) {
                        System.out.println("Funcionário cadastrado com sucesso: " + funcionario.getNome());
                    }
                    break;
                case 4:
                    // Cadastrar Livro
                    livro novoLivro = cadastro.cadastroLivro();
                    if (novoLivro != null) {
                        System.out.println("Livro cadastrado com sucesso: " + novoLivro.getTitulo());
                    }
                    break;
                case 5:
                    // Sair do sistema
                    System.out.println("Encerrando o sistema...");
                    rodando = false;
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
}
