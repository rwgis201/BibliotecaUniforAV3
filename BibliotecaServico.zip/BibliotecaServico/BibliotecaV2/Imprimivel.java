package ProjetoBiblioteca;

abstract class Imprimivel {
    public abstract void imprimirDetalhes();


}
