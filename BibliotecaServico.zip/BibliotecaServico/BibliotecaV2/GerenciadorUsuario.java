package ProjetoBiblioteca;

public class GerenciadorUsuario {
    public void MetAluno(){

    }

    public void MetProfessor(){

    }

    public void MetFuncionarios(){

    }
}
