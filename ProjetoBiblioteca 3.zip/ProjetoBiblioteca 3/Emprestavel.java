package ProjetoBiblioteca;

public interface Emprestavel {

    public void emprestavel();
    }

