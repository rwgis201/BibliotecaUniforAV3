package ProjetoBiblioteca;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Principal extends JFrame {

    private ArrayList<Usuario> usuarios;
    private ArrayList<livro> livros;
    private ArrayList<periodico> periodicos;
    private Relatorio relatorio;

    public Principal() {
        super("Sistema de Biblioteca");
        usuarios = new ArrayList<>();
        livros = new ArrayList<>();
        periodicos = new ArrayList<>();
        relatorio = new Relatorio();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        JPanel painelPrincipal = new JPanel();
        painelPrincipal.setLayout(new BorderLayout());
        add(painelPrincipal);

        JLabel titulo = new JLabel("Biblioteca Unifor", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        painelPrincipal.add(titulo, BorderLayout.NORTH);

        JTabbedPane abas = new JTabbedPane();
        painelPrincipal.add(abas, BorderLayout.CENTER);

        // Aba de Cadastro
        JPanel abaCadastro = new JPanel();
        abaCadastro.setLayout(new GridLayout(5, 1, 10, 10));
        abas.addTab("Cadastro", abaCadastro);

        JButton botaoCadastrarAluno = new JButton("Cadastrar Aluno");
        JButton botaoCadastrarProfessor = new JButton("Cadastrar Professor");
        JButton botaoCadastrarFuncionario = new JButton("Cadastrar Funcionário");
        JButton botaoCadastrarLivro = new JButton("Cadastrar Livro");
        JButton botaoCadastrarPeriodico = new JButton("Cadastrar Periódico");
        abaCadastro.add(botaoCadastrarAluno);
        abaCadastro.add(botaoCadastrarProfessor);
        abaCadastro.add(botaoCadastrarFuncionario);
        abaCadastro.add(botaoCadastrarLivro);
        abaCadastro.add(botaoCadastrarPeriodico);

        botaoCadastrarAluno.addActionListener(e -> {
            Usuario novoUsuario = abrirTelaCadastroUsuario("Aluno");
            if (novoUsuario != null) {
                usuarios.add(novoUsuario);
                JOptionPane.showMessageDialog(Principal.this, "Aluno cadastrado com sucesso!");
            }
        });

        botaoCadastrarProfessor.addActionListener(e -> {
            Usuario novoUsuario = abrirTelaCadastroUsuario("Professor");
            if (novoUsuario != null) {
                usuarios.add(novoUsuario);
                JOptionPane.showMessageDialog(Principal.this, "Professor cadastrado com sucesso!");
            }
        });

        botaoCadastrarFuncionario.addActionListener(e -> {
            Usuario novoUsuario = abrirTelaCadastroUsuario("Funcionário");
            if (novoUsuario != null) {
                usuarios.add(novoUsuario);
                JOptionPane.showMessageDialog(Principal.this, "Funcionário cadastrado com sucesso!");
            }
        });

        botaoCadastrarLivro.addActionListener(e -> {
            livro novoLivro = abrirTelaCadastroLivro();
            if (novoLivro != null) {
                livros.add(novoLivro);
                JOptionPane.showMessageDialog(Principal.this, "Livro cadastrado com sucesso!");
            }
        });

        botaoCadastrarPeriodico.addActionListener(e -> {
            periodico novoPeriodico = abrirTelaCadastroPeriodico();
            if (novoPeriodico != null) {
                periodicos.add(novoPeriodico);
                JOptionPane.showMessageDialog(Principal.this, "Periódico cadastrado com sucesso!");
            }
        });

        // Aba de Empréstimo
        JPanel abaEmprestimo = new JPanel();
        abaEmprestimo.setLayout(new GridLayout(6, 2, 10, 10));
        abas.addTab("Empréstimo", abaEmprestimo);

        JLabel labelMatricula = new JLabel("Matrícula:");
        JTextField campoMatricula = new JTextField();
        JLabel labelTituloItem = new JLabel("Título do Item:");
        JTextField campoTituloItem = new JTextField();
        JLabel labelTipoItem = new JLabel("Tipo de Item:");
        JComboBox<String> comboTipoItem = new JComboBox<>(new String[]{"Livro", "Periódico"});
        JButton botaoEmprestar = new JButton("Emprestar");

        abaEmprestimo.add(labelMatricula);
        abaEmprestimo.add(campoMatricula);
        abaEmprestimo.add(labelTituloItem);
        abaEmprestimo.add(campoTituloItem);
        abaEmprestimo.add(labelTipoItem);
        abaEmprestimo.add(comboTipoItem);
        abaEmprestimo.add(botaoEmprestar);



        botaoEmprestar.addActionListener(e -> {
            String tipoItem = (String) comboTipoItem.getSelectedItem();
            if (tipoItem.equals("Livro")) {
                realizarEmprestimoLivro(campoMatricula.getText(), campoTituloItem.getText());
                relatorio.gerarRelatorioEmprestimosLivros(livros);
            } else {
                realizarEmprestimoPeriodico(campoMatricula.getText(), campoTituloItem.getText());
                relatorio.gerarRelatorioEmprestimosPeriodicos(periodicos);
            }
        });

        // Aba de Devolução
        JPanel abaDevolucao = new JPanel();
        abaDevolucao.setLayout(new GridLayout(6, 2, 10, 10));
        abas.addTab("Devolução", abaDevolucao);

        JLabel labelMatriculaDevolucao = new JLabel("Matrícula:");
        JTextField campoMatriculaDevolucao = new JTextField();
        JLabel labelTituloItemDevolucao = new JLabel("Título do Item:");
        JTextField campoTituloItemDevolucao = new JTextField();
        JLabel labelTipoItemDevolucao = new JLabel("Tipo de Item:");
        JComboBox<String> comboTipoItemDevolucao = new JComboBox<>(new String[]{"Livro", "Periódico"});
        JButton botaoDevolver = new JButton("Devolver");

        abaDevolucao.add(labelMatriculaDevolucao);
        abaDevolucao.add(campoMatriculaDevolucao);
        abaDevolucao.add(labelTituloItemDevolucao);
        abaDevolucao.add(campoTituloItemDevolucao);
        abaDevolucao.add(labelTipoItemDevolucao);
        abaDevolucao.add(comboTipoItemDevolucao);
        abaDevolucao.add(botaoDevolver);

        botaoDevolver.addActionListener(e -> {
            String tipoItem = (String) comboTipoItemDevolucao.getSelectedItem();
            if (tipoItem.equals("Livro")) {
                realizarDevolucaoLivro(campoMatriculaDevolucao.getText(), campoTituloItemDevolucao.getText());
                relatorio.gerarRelatorioDevolucoesLivros(livros);
            } else {
                realizarDevolucaoPeriodico(campoMatriculaDevolucao.getText(), campoTituloItemDevolucao.getText());
                relatorio.gerarRelatorioDevolucoesPeriodicos(periodicos);
            }
        });

        setVisible(true);
    }

    private Usuario abrirTelaCadastroUsuario(String tipoUsuario) {
        JPanel painel = new JPanel(new GridLayout(5, 2, 10, 10));
        JLabel labelMatricula = new JLabel("Matrícula:");
        JTextField campoMatricula = new JTextField();
        JLabel labelNome = new JLabel("Nome:");
        JTextField campoNome = new JTextField();
        JLabel labelCEP = new JLabel("CEP:");
        JTextField campoCEP = new JTextField();
        JLabel labelTelefone = new JLabel("Telefone:");
        JTextField campoTelefone = new JTextField();

        painel.add(labelMatricula);
        painel.add(campoMatricula);
        painel.add(labelNome);
        painel.add(campoNome);
        painel.add(labelCEP);
        painel.add(campoCEP);
        painel.add(labelTelefone);
        painel.add(campoTelefone);

        int resultado = JOptionPane.showConfirmDialog(this, painel, "Cadastro de " + tipoUsuario, JOptionPane.OK_CANCEL_OPTION);
        if (resultado == JOptionPane.OK_OPTION) {
            try {
                int matricula = Integer.parseInt(campoMatricula.getText());
                String nome = campoNome.getText();
                String endereco = campoCEP.getText();
                String telefone = campoTelefone.getText();
                return new Usuario(matricula, nome, endereco, telefone);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Matrícula inválida. Digite um número inteiro.", "Erro", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        return null;
    }


    private livro abrirTelaCadastroLivro() {
        JPanel painel = new JPanel(new GridLayout(6, 2, 10, 10));
        JLabel labelTitulo = new JLabel("Título:");
        JTextField campoTitulo = new JTextField();
        JLabel labelAutor = new JLabel("Autor:");
        JTextField campoAutor = new JTextField();
        JLabel labelIsbn = new JLabel("ISBN:");
        JTextField campoIsbn = new JTextField();
        JLabel labelAnoPublicacao = new JLabel("Ano de Publicação:");
        JTextField campoAnoPublicacao = new JTextField();
        JLabel labelEditora = new JLabel("Editora:");
        JTextField campoEditora = new JTextField();
        JLabel labelNumExemplares = new JLabel("Número de Exemplares:");
        JTextField campoNumExemplares = new JTextField();

        painel.add(labelTitulo);
        painel.add(campoTitulo);
        painel.add(labelAutor);
        painel.add(campoAutor);
        painel.add(labelIsbn);
        painel.add(campoIsbn);
        painel.add(labelAnoPublicacao);
        painel.add(campoAnoPublicacao);
        painel.add(labelEditora);
        painel.add(campoEditora);
        painel.add(labelNumExemplares);
        painel.add(campoNumExemplares);

        int resultado = JOptionPane.showConfirmDialog(this, painel, "Cadastro de Livro", JOptionPane.OK_CANCEL_OPTION);
        if (resultado == JOptionPane.OK_OPTION) {
            try {
                String titulo = campoTitulo.getText();
                String autor = campoAutor.getText();
                String isbn = campoIsbn.getText();
                int anoPublicacao = Integer.parseInt(campoAnoPublicacao.getText());
                String editora = campoEditora.getText();
                int numExemplares = Integer.parseInt(campoNumExemplares.getText());
                return new livro(titulo, autor, isbn, anoPublicacao, editora, numExemplares);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ano de Publicação/Número de Exemplares inválido. Digite um número inteiro.", "Erro", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        return null;
    }

    private periodico abrirTelaCadastroPeriodico() {
        JPanel painel = new JPanel(new GridLayout(5, 2, 10, 10));
        JLabel labelTitulo = new JLabel("Título:");
        JTextField campoTitulo = new JTextField();
        JLabel labelAutor = new JLabel("Autor:");
        JTextField campoAutor = new JTextField();
        JLabel labelEditora = new JLabel("Editora:");
        JTextField campoEditora = new JTextField();
        JLabel labelAnoPublicacao = new JLabel("Ano de Publicação:");
        JTextField campoAnoPublicacao = new JTextField();

        painel.add(labelTitulo);
        painel.add(campoTitulo);
        painel.add(labelAutor);
        painel.add(campoAutor);
        painel.add(labelEditora);
        painel.add(campoEditora);
        painel.add(labelAnoPublicacao);
        painel.add(campoAnoPublicacao);

        int resultado = JOptionPane.showConfirmDialog(this, painel, "Cadastro de Periódico", JOptionPane.OK_CANCEL_OPTION);
        if (resultado == JOptionPane.OK_OPTION) {
            try {
                String titulo = campoTitulo.getText();
                String autor = campoAutor.getText();
                String editora = campoEditora.getText();
                int anoPublicacao = Integer.parseInt(campoAnoPublicacao.getText());
                return new periodico(titulo, autor, editora, anoPublicacao);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ano de Publicação inválido. Digite um número inteiro.", "Erro", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        return null;
    }

    private void realizarEmprestimoLivro(String matricula, String tituloLivro) {
        if (matricula.isEmpty() || tituloLivro.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, informe a matrícula e o título do livro.");
            return;
        }

        Usuario usuario = null;
        for (Usuario u : usuarios) {
            if (String.valueOf(u.getMatricula()).equals(matricula)) {
                usuario = u;
                break;
            }
        }

        if (usuario == null) {
            JOptionPane.showMessageDialog(this, "Usuário não encontrado.");
            return;
        }

        livro livro = null;
        for (livro l : livros) {
            if (l.getTitulo().equals(tituloLivro)) {
                livro = l;
                break;
            }
        }

        if (livro == null) {
            JOptionPane.showMessageDialog(this, "Livro não encontrado.");
            return;
        }

        if (Integer.parseInt(livro.getNumExemplaresDisponiveis()) > 0) {
            livro.emprestar();
            JOptionPane.showMessageDialog(this, "Livro emprestado com sucesso para " + usuario.getNome() + "!");
        } else {
            JOptionPane.showMessageDialog(this, "Livro indisponível no momento.");
        }
    }

    private void realizarDevolucaoLivro(String matricula, String tituloLivro) {
        if (matricula.isEmpty() || tituloLivro.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, informe a matrícula e o título do livro.");
            return;
        }

        livro livro = null;
        for (livro l : livros) {
            if (l.getTitulo().equals(tituloLivro)) {
                livro = l;
                break;
            }
        }

        if (livro == null) {
            JOptionPane.showMessageDialog(this, "Livro não encontrado.");
            return;
        }

        livro.devolver();
        JOptionPane.showMessageDialog(this, "Livro devolvido com sucesso!");
    }

    private void realizarEmprestimoPeriodico(String matricula, String tituloPeriodico) {
        // Implemente a lógica de empréstimo de periódico aqui
        // ...
    }

    private void realizarDevolucaoPeriodico(String matricula, String tituloPeriodico) {
        // Implemente a lógica de devolução de periódico aqui
        // ...
    }

    public static void main(String[] args) {
        new Principal();
    }
}