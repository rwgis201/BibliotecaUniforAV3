package ProjetoBiblioteca;

public class GerenciadorUsuario {
    public void MetUsuario() {

    }
}
