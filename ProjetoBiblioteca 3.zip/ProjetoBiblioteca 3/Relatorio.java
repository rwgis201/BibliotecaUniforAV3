package ProjetoBiblioteca;

import java.util.ArrayList;

public class Relatorio {

    public void gerarRelatorioEmprestimosLivros(ArrayList<livro> livros) {
        System.out.println("Relatório de Empréstimos de Livros:");
        for (livro l : livros) {
            System.out.println("Título: " + l.getTitulo() + ", Disponíveis: " + l.getNumExemplaresDisponiveis());
        }
    }

    public void gerarRelatorioDevolucoesLivros(ArrayList<livro> livros) {
        System.out.println("Relatório de Devoluções de Livros:");
        for (livro l : livros) {
            System.out.println("Título: " + l.getTitulo() + ", Disponíveis: " + l.getNumExemplaresDisponiveis());
        }
    }

    public void gerarRelatorioEmprestimosPeriodicos(ArrayList<periodico> periodicos) {
        System.out.println("Relatório de Empréstimos de Periódicos:");
        for (periodico p : periodicos) {
            System.out.println("Título: " + p.getTitulo() + ", Autor: " + p.getAutor() + ", Editora: " + p.getEditora());
        }
    }

    public void gerarRelatorioDevolucoesPeriodicos(ArrayList<periodico> periodicos) {
        System.out.println("Relatório de Devoluções de Periódicos:");
        for (periodico p : periodicos) {
            System.out.println("Título: " + p.getTitulo() + ", Autor: " + p.getAutor() + ", Editora: " + p.getEditora());
        }
    }
}