package ProjetoBiblioteca;

public interface Acervo {

    public void localizacao();
}
