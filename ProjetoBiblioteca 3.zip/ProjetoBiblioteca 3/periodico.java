package ProjetoBiblioteca;

public class periodico implements Acervo { // Implementa a interface Acervo
    private String titulo;
    private String autor;
    private String editora;
    private int anoPublicacao;
    private int numExemplares;
    private int numExemplaresDisponiveis; // Adiciona atributos para controle de exemplares

    public periodico(String titulo, String autor, String editora, int anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.editora = editora;
        this.anoPublicacao = anoPublicacao;
        this.numExemplares = numExemplares;
        this.numExemplaresDisponiveis = numExemplares;
    }

    // Remove o método PeriodicoLeitura, que não parece ter utilidade

    @Override
    public void localizacao() {
        System.out.println("Localização: Seção de periódicos");
    }

    // Adiciona métodos para controle de empréstimo
    public void emprestar() {
        if (numExemplaresDisponiveis > 0) {
            numExemplaresDisponiveis--;
            System.out.println("Periódico emprestado com sucesso!");
        } else {
            System.out.println("Não há exemplares disponíveis para empréstimo.");
        }
    }

    public void devolver() {
        if (numExemplaresDisponiveis < numExemplares) {
            numExemplaresDisponiveis++;
            System.out.println("Periódico devolvido com sucesso!");
        } else {
            System.out.println("Todos os exemplares já estão disponíveis.");
        }
    }

    // Adiciona getters para os atributos
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public String getEditora() {
        return editora;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public String getNumExemplaresDisponiveis() {
        return String.valueOf(numExemplaresDisponiveis);
    }
}